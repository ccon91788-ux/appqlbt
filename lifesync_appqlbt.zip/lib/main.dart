import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'data/notif.dart';
import 'data/repo.dart';
import 'screens/flashcards_screen.dart';
import 'screens/money_screen.dart';
import 'screens/mind_map_screen.dart';
import 'screens/calendar_screen.dart';
import 'screens/notes_screen.dart';
import 'services/drive_service.dart';
import 'services/update_service.dart';
import 'ui.dart';

final ValueNotifier<ThemeMode> themeMode = ValueNotifier(ThemeMode.system);
final ValueNotifier<bool> showLunar = ValueNotifier(true);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('vi');
  try {
    final sp = await SharedPreferences.getInstance();
    themeMode.value = ThemeMode.values[(sp.getInt('theme') ?? 0).clamp(0, 2)];
    showLunar.value = sp.getBool('lunar') ?? true;
  } catch (_) {}
  try {
    await Repo.categories();
  } catch (_) {}
  try {
    await Notif.init();
    await Repo.cancelLegacyBillAlarms();
    await Notif.rescheduleAll(await Repo.events());
    await Notif.rescheduleAllTasks(await Repo.tasks());
  } catch (_) {}
  // Sao lưu tự động lên Google Drive nếu người dùng đã bật (chạy nền,
  // mọi lỗi đều được bỏ qua để không làm chậm hay làm phiền app).
  unawaited(DriveService.maybeAutoBackup());
  runApp(const LifeSyncApp());
}

class LifeSyncApp extends StatelessWidget {
  const LifeSyncApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeMode,
      builder: (context, mode, _) => MaterialApp(
        title: 'LifeSync',
        debugShowCheckedModeBanner: false,
        themeMode: mode,
        theme: buildTheme(Brightness.light),
        darkTheme: buildTheme(Brightness.dark),
        locale: const Locale('vi'),
        supportedLocales: const [Locale('vi')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        home: const Shell(),
      ),
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _i = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (await UpdateService.autoEnabled() && mounted) {
        await UpdateService.check(context, silent: true);
      }
    });
  }

  static const _pages = [CalendarScreen(), MoneyScreen(), NotesScreen(), MindMapScreen(), FlashcardsScreen()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(bottom: false, child: IndexedStack(index: _i, children: _pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _i,
        onDestinationSelected: (v) => setState(() => _i = v),
        destinations: const [
          NavigationDestination(icon: Text('🗓️', style: TextStyle(fontSize: 22)), label: 'Lịch'),
          NavigationDestination(icon: Text('👛', style: TextStyle(fontSize: 22)), label: 'Tài chính'),
          NavigationDestination(icon: Text('📝', style: TextStyle(fontSize: 22)), label: 'Ghi chú'),
          NavigationDestination(icon: Icon(Icons.account_tree_outlined), label: 'Sơ đồ tư duy'),
          NavigationDestination(icon: Icon(Icons.style_outlined), label: 'Flashcards'),
        ],
      ),
    );
  }
}
